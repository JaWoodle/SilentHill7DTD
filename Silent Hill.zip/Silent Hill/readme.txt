Mods go in the mods folder.

Overwrite the "managed" folder in "7DaysToDie_Data" with the new folder.

TURN EAC OFF WHEN RUNNING MODIFIED FILES!