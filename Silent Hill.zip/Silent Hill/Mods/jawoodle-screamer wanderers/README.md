# Demolition Zombies!

## 7 Days 2 Die Modlet

Adds chance to spawn demolition zombies in the game
