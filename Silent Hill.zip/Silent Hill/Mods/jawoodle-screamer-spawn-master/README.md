# Screamer Spawns

## 7 Days 2 Die Modlet

Adds chance to spawn screamer zombies in the game
