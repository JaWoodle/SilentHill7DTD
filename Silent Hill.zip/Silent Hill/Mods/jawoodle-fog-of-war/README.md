# JaWoodle's Doomsday Settings

## 7 Days 2 Die Modlet

Sets the global fog level across all biomes.
